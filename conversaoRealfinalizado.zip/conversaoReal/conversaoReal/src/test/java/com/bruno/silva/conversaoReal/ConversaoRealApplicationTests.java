package com.bruno.silva.conversaoReal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConversaoRealApplicationTests {

	@Test
	void contextLoads() {
	}

}
