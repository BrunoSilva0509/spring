package com.bruno.silva.conversaoReal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConversaoRealApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConversaoRealApplication.class, args);
		System.out.println("Hello World");
	}

}
