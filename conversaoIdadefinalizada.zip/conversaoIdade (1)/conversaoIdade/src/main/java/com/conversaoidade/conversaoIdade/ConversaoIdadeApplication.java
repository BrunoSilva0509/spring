package com.conversaoidade.conversaoIdade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConversaoIdadeApplication {

	public static void main(String[] args) { SpringApplication.run(ConversaoIdadeApplication.class, args);
		System.out.println("Hello World");
	}

}
