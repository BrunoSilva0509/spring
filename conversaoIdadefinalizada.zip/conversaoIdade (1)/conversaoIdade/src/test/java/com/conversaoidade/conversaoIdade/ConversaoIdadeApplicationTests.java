package com.conversaoidade.conversaoIdade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConversaoIdadeApplicationTests {

	@Test
	void contextLoads() {
	}

}
